Este proyecto es un ejemplo de implementación de JPA y Hibernate utilizando la base de datos H2.
